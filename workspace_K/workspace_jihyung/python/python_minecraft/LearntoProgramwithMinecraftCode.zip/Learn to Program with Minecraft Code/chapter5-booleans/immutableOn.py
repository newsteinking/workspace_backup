from mcpi.minecraft import Minecraft
mc = Minecraft.create()

mc.setting("world_immutable", True)
