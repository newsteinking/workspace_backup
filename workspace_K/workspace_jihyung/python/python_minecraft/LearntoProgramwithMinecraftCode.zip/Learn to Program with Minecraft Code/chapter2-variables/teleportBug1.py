from mcpi.minceraft inport Minecraft
# mc = Minecraft.create()

x = 10
  y = 11
z = 12